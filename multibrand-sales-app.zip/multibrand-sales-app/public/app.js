let currentChart = null;
let appConfig = { hasServerKey: false, defaultModel: 'gemini-2.5-flash' };

const state = {
  report: null,
  manufacturers: window.APP_CATALOG.manufacturers || []
};

function $(id) {
  return document.getElementById(id);
}

async function init() {
  await loadConfig();
  loadManufacturers();
  bindEvents();
}

async function loadConfig() {
  try {
    const res = await fetch('/api/config');
    appConfig = await res.json();
    $('statusText').textContent = appConfig.hasServerKey
      ? `Servidor listo. Modelo por defecto: ${appConfig.defaultModel}.`
      : 'No hay GEMINI_API_KEY en el servidor. Debes pegar una API key en la interfaz.';
  } catch (_e) {
    $('statusText').textContent = 'No fue posible leer la configuración del servidor.';
  }
}

function loadManufacturers() {
  const select = $('manufacturerSelect');
  select.innerHTML = state.manufacturers
    .map((m, i) => `<option value="${m.name}" ${i === 0 ? 'selected' : ''}>${m.name}</option>`)
    .join('');

  updateSolutions();
  renderPortfolioInfo();
}

function bindEvents() {
  $('manufacturerSelect').addEventListener('change', () => {
    updateSolutions();
    renderPortfolioInfo();
  });

  $('solutionSelect').addEventListener('change', renderPortfolioInfo);
  $('generateBtn').addEventListener('click', handleGenerate);
  $('demoBtn').addEventListener('click', loadDemo);
  $('companyInput').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') handleGenerate();
  });
}

function getSelectedManufacturer() {
  const name = $('manufacturerSelect').value;
  return state.manufacturers.find((m) => m.name === name);
}

function updateSolutions() {
  const manufacturer = getSelectedManufacturer();
  const solutionSelect = $('solutionSelect');
  const solutions = manufacturer?.solutions || [];
  solutionSelect.innerHTML = solutions
    .map((s, i) => `<option value="${s.name}" ${i === 0 ? 'selected' : ''}>${s.name}</option>`)
    .join('');
}

function getSelectedSolution() {
  const manufacturer = getSelectedManufacturer();
  const solutionName = $('solutionSelect').value;
  return manufacturer?.solutions.find((s) => s.name === solutionName);
}

function renderPortfolioInfo() {
  const manufacturer = getSelectedManufacturer();
  const solution = getSelectedSolution();

  $('portfolioInfo').innerHTML = `
    <div>
      <p class="text-xs font-bold uppercase tracking-wider text-slate-500">Fabricante</p>
      <p class="text-lg font-black text-slate-900">${manufacturer?.name || '-'}</p>
      <p class="text-sm text-slate-600 mt-1">${manufacturer?.description || ''}</p>
    </div>
    <div>
      <p class="text-xs font-bold uppercase tracking-wider text-slate-500">Solución</p>
      <p class="text-base font-bold text-blue-700">${solution?.name || '-'}</p>
    </div>
    <div>
      <p class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Productos sugeridos</p>
      <div class="flex flex-wrap gap-2">
        ${(solution?.products || []).map((p) => `<span class="rounded-full bg-white border border-slate-200 px-3 py-1 text-xs font-medium">${p}</span>`).join('')}
      </div>
    </div>
    <div>
      <p class="text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">Valor esperado</p>
      <div class="flex flex-wrap gap-2">
        ${(solution?.value || []).map((v) => `<span class="rounded-full bg-blue-100 text-blue-900 px-3 py-1 text-xs font-medium">${v}</span>`).join('')}
      </div>
    </div>
  `;
}

function showLoading(isLoading) {
  $('loadingBox').classList.toggle('hidden', !isLoading);
  $('generateBtn').disabled = isLoading;
  $('demoBtn').disabled = isLoading;
}

function showError(message) {
  const el = $('errorText');
  if (!message) {
    el.classList.add('hidden');
    el.textContent = '';
    return;
  }
  el.textContent = message;
  el.classList.remove('hidden');
}

async function handleGenerate() {
  showError('');

  const companyName = $('companyInput').value.trim();
  const manufacturer = $('manufacturerSelect').value;
  const solution = $('solutionSelect').value;
  const country = $('countryInput').value.trim();
  const notes = $('notesInput').value.trim();
  const apiKey = $('apiKeyInput').value.trim();

  if (!companyName) {
    showError('Debes indicar la empresa objetivo.');
    return;
  }

  if (!appConfig.hasServerKey && !apiKey) {
    showError('No existe API key en el servidor. Pega una API key de Gemini en el campo superior.');
    return;
  }

  showLoading(true);
  $('statusText').textContent = 'Generando análisis multimarca...';

  try {
    const response = await fetch('/api/generate-profile', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ companyName, manufacturer, solution, country, notes, apiKey })
    });

    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || 'No fue posible generar el análisis.');
    }

    state.report = data;
    renderReport(data);
    $('statusText').textContent = 'Análisis generado correctamente.';
  } catch (error) {
    showError(error.message || 'Error inesperado.');
    $('statusText').textContent = 'Falló la generación del análisis.';
  } finally {
    showLoading(false);
  }
}

function loadDemo() {
  const demo = {
    empresa: 'Bancolombia',
    fabricante: 'F5',
    solucion: 'WAAP',
    resumenEjecutivo: 'Bancolombia depende de canales digitales de alto tráfico y expuestos a fraude, automatización maliciosa y presión regulatoria. Una estrategia WAAP ayuda a proteger banca web, APIs y experiencia digital con controles más específicos para aplicaciones críticas.',
    perfilamiento: {
      sector: 'Servicios financieros',
      geografia: 'Colombia y operación regional',
      core: 'Servicios bancarios, canales transaccionales, pagos y productos financieros para personas y empresas.',
      rol: 'CISO / Director de Seguridad / Líder de Canales Digitales',
      activosCriticos: ['Portal transaccional', 'APIs de banca móvil', 'Identidad digital', 'Integraciones con terceros']
    },
    riesgos: {
      tiposDatos: [
        { label: 'Datos transaccionales', value: 35 },
        { label: 'Credenciales y sesiones', value: 25 },
        { label: 'Datos personales', value: 20 },
        { label: 'APIs y metadatos', value: 20 }
      ],
      riesgoPrincipal: 'Abuso de bots, explotación de APIs y ataques sobre aplicaciones expuestas.',
      impacto: 'Fraude, indisponibilidad, sanciones y deterioro de confianza del cliente.'
    },
    casosDeUso: [
      {
        titulo: 'Protección de portal transaccional',
        dolor: 'Aplicaciones críticas con exposición constante a intentos de explotación y automatización maliciosa.',
        solucion: 'WAAP de F5 permite combinar WAF, defensa de bots y protección de APIs con visibilidad centralizada.',
        resultado: 'Menor superficie de fraude y mejor continuidad del servicio.'
      },
      {
        titulo: 'Seguridad de APIs',
        dolor: 'Inventario parcial de APIs y dificultad para detectar comportamiento anómalo.',
        solucion: 'Descubrimiento y protección de APIs en canales móviles y ecosistemas de terceros.',
        resultado: 'Reducción del riesgo de abuso y mejor gobierno del ciclo de vida API.'
      }
    ],
    pitch: {
      apertura: 'Vemos una organización con una dependencia crítica de canales digitales y una superficie de exposición creciente en aplicaciones y APIs.',
      valor: 'F5 WAAP puede ayudarles a unificar protección web, defensa de bots y seguridad de APIs con foco en disponibilidad, visibilidad y reducción de fraude.',
      cierre: 'La siguiente conversación debería centrarse en priorizar aplicaciones y APIs de mayor criticidad para construir una ruta de protección por fases.'
    },
    competencias: ['Protección avanzada de aplicaciones', 'Mitigación de bots y abuso automatizado', 'Visibilidad y postura de APIs'],
    normativo: [
      { norma: 'Habeas Data', descripcion: 'Protección de datos personales y trazabilidad del tratamiento.' },
      { norma: 'Circulars de la SFC', descripcion: 'Controles de seguridad y continuidad en entidades vigiladas.' }
    ],
    preguntasDescubrimiento: [
      '¿Qué aplicaciones y APIs tienen hoy mayor impacto en ingreso o experiencia del cliente?',
      '¿Cómo están detectando abuso automatizado o fraude sobre canales digitales?',
      '¿Tienen visibilidad completa del inventario y exposición de APIs?'
    ],
    arquitecturaSugerida: ['F5 Distributed Cloud WAAP', 'Bot Defense', 'API Security', 'Integración con SIEM/SOC'],
    fuentes: ['bancolombia.com', 'superfinanciera.gov.co', 'f5.com']
  };

  $('companyInput').value = demo.empresa;
  $('countryInput').value = 'Colombia';
  $('manufacturerSelect').value = demo.fabricante;
  updateSolutions();
  $('solutionSelect').value = demo.solucion;
  renderPortfolioInfo();
  renderReport(demo);
  $('statusText').textContent = 'Demo cargada correctamente.';
  showError('');
}

function renderReport(data) {
  $('reportSection').classList.remove('hidden');
  $('rEmpresa').textContent = data.empresa || '-';
  $('rFabricante').textContent = data.fabricante || '-';
  $('rSolucion').textContent = data.solucion || '-';
  $('rSector').textContent = data.perfilamiento?.sector || '-';
  $('rGeografia').textContent = data.perfilamiento?.geografia || '-';
  $('rRol').textContent = data.perfilamiento?.rol || '-';
  $('rResumen').textContent = data.resumenEjecutivo || '-';
  $('rRiesgoPrincipal').textContent = data.riesgos?.riesgoPrincipal || '-';
  $('rImpacto').textContent = data.riesgos?.impacto || '-';
  $('pApertura').textContent = data.pitch?.apertura || '-';
  $('pValor').textContent = data.pitch?.valor || '-';
  $('pCierre').textContent = data.pitch?.cierre || '-';

  renderSimpleList('activosList', data.perfilamiento?.activosCriticos, 'bg-slate-50 border-slate-200');
  renderSimpleList('competenciasList', data.competencias, 'bg-blue-50 border-blue-100');
  renderSimpleList('arquitecturaList', data.arquitecturaSugerida, 'bg-emerald-50 border-emerald-100');
  renderSimpleList('preguntasList', data.preguntasDescubrimiento, 'bg-slate-50 border-slate-200');
  renderSimpleList('fuentesList', data.fuentes, 'bg-slate-50 border-slate-200');

  const normativoList = $('normativoList');
  normativoList.innerHTML = '';
  (data.normativo || []).forEach((item) => {
    normativoList.innerHTML += `
      <li class="rounded-xl border border-slate-200 bg-slate-50 p-4">
        <p class="font-bold text-slate-900">${item.norma || '-'}</p>
        <p class="text-slate-600 mt-1">${item.descripcion || ''}</p>
      </li>
    `;
  });

  const casos = $('casosContainer');
  casos.innerHTML = '';
  (data.casosDeUso || []).forEach((item) => {
    casos.innerHTML += `
      <div class="rounded-xl border border-slate-200 p-4 bg-slate-50">
        <h4 class="font-black text-slate-900">${item.titulo || '-'}</h4>
        <p class="text-sm mt-2"><span class="font-bold">Dolor:</span> ${item.dolor || ''}</p>
        <p class="text-sm mt-2"><span class="font-bold">Solución:</span> ${item.solucion || ''}</p>
        <p class="text-sm mt-2"><span class="font-bold">Resultado:</span> ${item.resultado || ''}</p>
      </div>
    `;
  });

  renderChart(data.riesgos?.tiposDatos || []);
  window.scrollTo({ top: document.body.scrollHeight * 0.15, behavior: 'smooth' });
}

function renderSimpleList(elementId, items = [], classes = '') {
  const el = $(elementId);
  el.innerHTML = '';
  (items || []).forEach((item) => {
    el.innerHTML += `<li class="rounded-xl border p-3 ${classes}">${item}</li>`;
  });
}

function renderChart(dataObj) {
  const ctx = $('riskChart').getContext('2d');
  if (currentChart) currentChart.destroy();

  currentChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: dataObj.map((d) => d.label),
      datasets: [{ data: dataObj.map((d) => d.value) }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom'
        }
      },
      cutout: '62%'
    }
  });
}

init();
